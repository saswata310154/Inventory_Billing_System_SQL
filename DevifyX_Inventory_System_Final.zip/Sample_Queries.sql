SELECT * FROM v_low_stock_alerts;
SELECT * FROM v_current_stock;
SELECT * FROM v_expiring_products;
SELECT customer_name, total_sales
SELECT supplier_name, total_purchases
SELECT * FROM v_product_performance
SELECT invoice_number, customer_id, status, balance_amount
SELECT * FROM payments
SELECT * FROM audit_logs
