-- DevifyX Inventory and Billing System
-- Database Schema Creation (DDL)
-- MySQL 8.0+ Required

-- Create Database
CREATE DATABASE IF NOT EXISTS inventory_billing_system;
USE inventory_billing_system;

-- Set SQL Mode for strict data validation
SET sql_mode = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- ===================================================================
-- 1. USER MANAGEMENT & ROLE-BASED ACCESS CONTROL
-- ===================================================================

-- Roles Table
CREATE TABLE roles (
    role_id INT PRIMARY KEY AUTO_INCREMENT,
    role_name VARCHAR(50) NOT NULL UNIQUE,
    description TEXT,
    permissions JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Users Table
CREATE TABLE users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role_id INT NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (role_id) REFERENCES roles(role_id)
) ENGINE=InnoDB;

-- ===================================================================
-- 2. LOCATION/WAREHOUSE MANAGEMENT
-- ===================================================================

-- Warehouses Table
CREATE TABLE warehouses (
    warehouse_id INT PRIMARY KEY AUTO_INCREMENT,
    warehouse_code VARCHAR(20) NOT NULL UNIQUE,
    warehouse_name VARCHAR(100) NOT NULL,
    address TEXT,
    city VARCHAR(50),
    state VARCHAR(50),
    postal_code VARCHAR(20),
    country VARCHAR(50),
    phone VARCHAR(20),
    email VARCHAR(100),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ===================================================================
-- 3. PRODUCT MANAGEMENT
-- ===================================================================

-- Categories Table
CREATE TABLE categories (
    category_id INT PRIMARY KEY AUTO_INCREMENT,
    category_name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    parent_category_id INT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (parent_category_id) REFERENCES categories(category_id)
) ENGINE=InnoDB;

-- Products Table
CREATE TABLE products (
    product_id INT PRIMARY KEY AUTO_INCREMENT,
    sku VARCHAR(50) NOT NULL UNIQUE,
    product_name VARCHAR(200) NOT NULL,
    description TEXT,
    category_id INT,
    unit_price DECIMAL(10,2) NOT NULL,
    cost_price DECIMAL(10,2),
    unit_of_measure VARCHAR(20) DEFAULT 'PCS',
    min_stock_level INT DEFAULT 0,
    max_stock_level INT DEFAULT 1000,
    reorder_point INT DEFAULT 10,
    has_batches BOOLEAN DEFAULT FALSE,
    has_expiry BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(category_id),
    INDEX idx_sku (sku),
    INDEX idx_product_category (category_id),
    INDEX idx_product_active (is_active)
) ENGINE=InnoDB;

-- Product Batches Table (for batch tracking)
CREATE TABLE product_batches (
    batch_id INT PRIMARY KEY AUTO_INCREMENT,
    product_id INT NOT NULL,
    batch_number VARCHAR(50) NOT NULL,
    manufacture_date DATE,
    expiry_date DATE,
    initial_quantity INT NOT NULL,
    current_quantity INT NOT NULL,
    cost_per_unit DECIMAL(10,2),
    warehouse_id INT NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    FOREIGN KEY (warehouse_id) REFERENCES warehouses(warehouse_id),
    UNIQUE KEY unique_batch_product (product_id, batch_number, warehouse_id),
    INDEX idx_batch_expiry (expiry_date),
    INDEX idx_batch_warehouse (warehouse_id)
) ENGINE=InnoDB;

-- ===================================================================
-- 4. SUPPLIER MANAGEMENT
-- ===================================================================

-- Suppliers Table
CREATE TABLE suppliers (
    supplier_id INT PRIMARY KEY AUTO_INCREMENT,
    supplier_code VARCHAR(20) NOT NULL UNIQUE,
    supplier_name VARCHAR(200) NOT NULL,
    contact_person VARCHAR(100),
    email VARCHAR(100),
    phone VARCHAR(20),
    mobile VARCHAR(20),
    address TEXT,
    city VARCHAR(50),
    state VARCHAR(50),
    postal_code VARCHAR(20),
    country VARCHAR(50),
    payment_terms VARCHAR(50),
    credit_limit DECIMAL(12,2) DEFAULT 0,
    tax_id VARCHAR(50),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_supplier_code (supplier_code),
    INDEX idx_supplier_active (is_active)
) ENGINE=InnoDB;

-- ===================================================================
-- 5. CUSTOMER MANAGEMENT
-- ===================================================================

-- Customers Table
CREATE TABLE customers (
    customer_id INT PRIMARY KEY AUTO_INCREMENT,
    customer_code VARCHAR(20) NOT NULL UNIQUE,
    customer_name VARCHAR(200) NOT NULL,
    contact_person VARCHAR(100),
    email VARCHAR(100),
    phone VARCHAR(20),
    mobile VARCHAR(20),
    billing_address TEXT,
    shipping_address TEXT,
    city VARCHAR(50),
    state VARCHAR(50),
    postal_code VARCHAR(20),
    country VARCHAR(50),
    payment_terms VARCHAR(50),
    credit_limit DECIMAL(12,2) DEFAULT 0,
    tax_id VARCHAR(50),
    customer_type ENUM('RETAIL', 'WHOLESALE', 'DISTRIBUTOR') DEFAULT 'RETAIL',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_customer_code (customer_code),
    INDEX idx_customer_type (customer_type),
    INDEX idx_customer_active (is_active)
) ENGINE=InnoDB;

-- ===================================================================
-- 6. PURCHASE ORDER MANAGEMENT
-- ===================================================================

-- Purchase Orders Table
CREATE TABLE purchase_orders (
    po_id INT PRIMARY KEY AUTO_INCREMENT,
    po_number VARCHAR(50) NOT NULL UNIQUE,
    supplier_id INT NOT NULL,
    warehouse_id INT NOT NULL,
    po_date DATE NOT NULL,
    expected_delivery_date DATE,
    status ENUM('DRAFT', 'SENT', 'CONFIRMED', 'PARTIALLY_RECEIVED', 'RECEIVED', 'CANCELLED') DEFAULT 'DRAFT',
    subtotal DECIMAL(12,2) DEFAULT 0,
    tax_amount DECIMAL(12,2) DEFAULT 0,
    discount_amount DECIMAL(12,2) DEFAULT 0,
    total_amount DECIMAL(12,2) DEFAULT 0,
    notes TEXT,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id),
    FOREIGN KEY (warehouse_id) REFERENCES warehouses(warehouse_id),
    FOREIGN KEY (created_by) REFERENCES users(user_id),
    INDEX idx_po_number (po_number),
    INDEX idx_po_supplier (supplier_id),
    INDEX idx_po_status (status),
    INDEX idx_po_date (po_date)
) ENGINE=InnoDB;

-- Purchase Order Items Table
CREATE TABLE purchase_order_items (
    poi_id INT PRIMARY KEY AUTO_INCREMENT,
    po_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity_ordered INT NOT NULL,
    quantity_received INT DEFAULT 0,
    unit_cost DECIMAL(10,4) NOT NULL,
    line_total DECIMAL(12,2) GENERATED ALWAYS AS (quantity_ordered * unit_cost) STORED,
    notes TEXT,
    FOREIGN KEY (po_id) REFERENCES purchase_orders(po_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    INDEX idx_poi_po (po_id),
    INDEX idx_poi_product (product_id)
) ENGINE=InnoDB;

-- Purchase Receipts Table
CREATE TABLE purchase_receipts (
    receipt_id INT PRIMARY KEY AUTO_INCREMENT,
    receipt_number VARCHAR(50) NOT NULL UNIQUE,
    po_id INT NOT NULL,
    supplier_id INT NOT NULL,
    warehouse_id INT NOT NULL,
    receipt_date DATE NOT NULL,
    total_amount DECIMAL(12,2) DEFAULT 0,
    notes TEXT,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (po_id) REFERENCES purchase_orders(po_id),
    FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id),
    FOREIGN KEY (warehouse_id) REFERENCES warehouses(warehouse_id),
    FOREIGN KEY (created_by) REFERENCES users(user_id),
    INDEX idx_receipt_po (po_id),
    INDEX idx_receipt_date (receipt_date)
) ENGINE=InnoDB;

-- Purchase Receipt Items Table
CREATE TABLE purchase_receipt_items (
    pri_id INT PRIMARY KEY AUTO_INCREMENT,
    receipt_id INT NOT NULL,
    product_id INT NOT NULL,
    batch_id INT NULL,
    quantity_received INT NOT NULL,
    unit_cost DECIMAL(10,4) NOT NULL,
    line_total DECIMAL(12,2) GENERATED ALWAYS AS (quantity_received * unit_cost) STORED,
    expiry_date DATE NULL,
    FOREIGN KEY (receipt_id) REFERENCES purchase_receipts(receipt_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    FOREIGN KEY (batch_id) REFERENCES product_batches(batch_id),
    INDEX idx_pri_receipt (receipt_id),
    INDEX idx_pri_product (product_id)
) ENGINE=InnoDB;

-- ===================================================================
-- 7. SALES ORDER & BILLING MANAGEMENT
-- ===================================================================

-- Sales Orders Table
CREATE TABLE sales_orders (
    so_id INT PRIMARY KEY AUTO_INCREMENT,
    so_number VARCHAR(50) NOT NULL UNIQUE,
    customer_id INT NOT NULL,
    warehouse_id INT NOT NULL,
    so_date DATE NOT NULL,
    delivery_date DATE,
    status ENUM('DRAFT', 'CONFIRMED', 'PARTIALLY_SHIPPED', 'SHIPPED', 'DELIVERED', 'CANCELLED') DEFAULT 'DRAFT',
    subtotal DECIMAL(12,2) DEFAULT 0,
    tax_amount DECIMAL(12,2) DEFAULT 0,
    discount_amount DECIMAL(12,2) DEFAULT 0,
    total_amount DECIMAL(12,2) DEFAULT 0,
    notes TEXT,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
    FOREIGN KEY (warehouse_id) REFERENCES warehouses(warehouse_id),
    FOREIGN KEY (created_by) REFERENCES users(user_id),
    INDEX idx_so_number (so_number),
    INDEX idx_so_customer (customer_id),
    INDEX idx_so_status (status),
    INDEX idx_so_date (so_date)
) ENGINE=InnoDB;

-- Sales Order Items Table
CREATE TABLE sales_order_items (
    soi_id INT PRIMARY KEY AUTO_INCREMENT,
    so_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity_ordered INT NOT NULL,
    quantity_shipped INT DEFAULT 0,
    unit_price DECIMAL(10,4) NOT NULL,
    line_total DECIMAL(12,2) GENERATED ALWAYS AS (quantity_ordered * unit_price) STORED,
    notes TEXT,
    FOREIGN KEY (so_id) REFERENCES sales_orders(so_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    INDEX idx_soi_so (so_id),
    INDEX idx_soi_product (product_id)
) ENGINE=InnoDB;

-- Invoices Table
CREATE TABLE invoices (
    invoice_id INT PRIMARY KEY AUTO_INCREMENT,
    invoice_number VARCHAR(50) NOT NULL UNIQUE,
    so_id INT NULL,
    customer_id INT NOT NULL,
    invoice_date DATE NOT NULL,
    due_date DATE NOT NULL,
    status ENUM('DRAFT', 'SENT', 'PAID', 'OVERDUE', 'CANCELLED') DEFAULT 'DRAFT',
    subtotal DECIMAL(12,2) DEFAULT 0,
    tax_amount DECIMAL(12,2) DEFAULT 0,
    discount_amount DECIMAL(12,2) DEFAULT 0,
    total_amount DECIMAL(12,2) DEFAULT 0,
    paid_amount DECIMAL(12,2) DEFAULT 0,
    balance_amount DECIMAL(12,2) GENERATED ALWAYS AS (total_amount - paid_amount) STORED,
    payment_terms VARCHAR(50),
    notes TEXT,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (so_id) REFERENCES sales_orders(so_id),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
    FOREIGN KEY (created_by) REFERENCES users(user_id),
    INDEX idx_invoice_number (invoice_number),
    INDEX idx_invoice_customer (customer_id),
    INDEX idx_invoice_status (status),
    INDEX idx_invoice_date (invoice_date),
    INDEX idx_invoice_due_date (due_date)
) ENGINE=InnoDB;

-- Invoice Items Table
CREATE TABLE invoice_items (
    ii_id INT PRIMARY KEY AUTO_INCREMENT,
    invoice_id INT NOT NULL,
    product_id INT NOT NULL,
    batch_id INT NULL,
    quantity INT NOT NULL,
    unit_price DECIMAL(10,4) NOT NULL,
    line_total DECIMAL(12,2) GENERATED ALWAYS AS (quantity * unit_price) STORED,
    tax_rate DECIMAL(5,2) DEFAULT 0,
    FOREIGN KEY (invoice_id) REFERENCES invoices(invoice_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    FOREIGN KEY (batch_id) REFERENCES product_batches(batch_id),
    INDEX idx_ii_invoice (invoice_id),
    INDEX idx_ii_product (product_id)
) ENGINE=InnoDB;

-- Payments Table
CREATE TABLE payments (
    payment_id INT PRIMARY KEY AUTO_INCREMENT,
    payment_number VARCHAR(50) NOT NULL UNIQUE,
    invoice_id INT NOT NULL,
    customer_id INT NOT NULL,
    payment_date DATE NOT NULL,
    payment_method ENUM('CASH', 'CREDIT_CARD', 'BANK_TRANSFER', 'CHECK', 'DIGITAL_WALLET') NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    reference_number VARCHAR(100),
    notes TEXT,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (invoice_id) REFERENCES invoices(invoice_id),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
    FOREIGN KEY (created_by) REFERENCES users(user_id),
    INDEX idx_payment_invoice (invoice_id),
    INDEX idx_payment_customer (customer_id),
    INDEX idx_payment_date (payment_date)
) ENGINE=InnoDB;

-- ===================================================================
-- 8. INVENTORY MANAGEMENT
-- ===================================================================

-- Stock Table (Current Stock Levels)
CREATE TABLE stock (
    stock_id INT PRIMARY KEY AUTO_INCREMENT,
    product_id INT NOT NULL,
    warehouse_id INT NOT NULL,
    batch_id INT NULL,
    quantity_on_hand INT NOT NULL DEFAULT 0,
    quantity_reserved INT NOT NULL DEFAULT 0,
    quantity_available INT GENERATED ALWAYS AS (quantity_on_hand - quantity_reserved) STORED,
    average_cost DECIMAL(10,4) DEFAULT 0,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    FOREIGN KEY (warehouse_id) REFERENCES warehouses(warehouse_id),
    FOREIGN KEY (batch_id) REFERENCES product_batches(batch_id),
    UNIQUE KEY unique_stock_location (product_id, warehouse_id, batch_id),
    INDEX idx_stock_product (product_id),
    INDEX idx_stock_warehouse (warehouse_id),
    INDEX idx_stock_available (quantity_available)
) ENGINE=InnoDB;

-- Stock Movements Table
CREATE TABLE stock_movements (
    movement_id INT PRIMARY KEY AUTO_INCREMENT,
    product_id INT NOT NULL,
    warehouse_id INT NOT NULL,
    batch_id INT NULL,
    movement_type ENUM('IN', 'OUT', 'ADJUSTMENT', 'TRANSFER') NOT NULL,
    reference_type ENUM('PURCHASE', 'SALE', 'ADJUSTMENT', 'TRANSFER', 'RETURN', 'INITIAL') NOT NULL,
    reference_id INT,
    so_number VARCHAR(50),
    customer_id INT,
    status ENUM('DRAFT', 'CONFIRMED', 'SHIPPED', 'DELIVERED', 'CANCELLED'),
    so_date DATE,
    quantity INT NOT NULL,
    unit_cost DECIMAL(10,4),
    total_cost DECIMAL(12,2),
    movement_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notes TEXT,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    FOREIGN KEY (warehouse_id) REFERENCES warehouses(warehouse_id),
    FOREIGN KEY (batch_id) REFERENCES product_batches(batch_id),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
    FOREIGN KEY (created_by) REFERENCES users(user_id),
    INDEX idx_movement_product (product_id),
    INDEX idx_movement_date (movement_date),
    INDEX idx_movement_type (movement_type),
    INDEX idx_movement_reference (reference_type, reference_id),
    INDEX idx_so_number (so_number),
    INDEX idx_so_customer (customer_id),
    INDEX idx_so_status (status),
    INDEX idx_so_date (so_date)
) ENGINE=InnoDB;

-- ===================================================================
-- 9. AUDIT LOGS
-- ===================================================================

-- Audit Logs Table
CREATE TABLE audit_logs (
    audit_id INT PRIMARY KEY AUTO_INCREMENT,
    table_name VARCHAR(64) NOT NULL,
    operation ENUM('INSERT', 'UPDATE', 'DELETE') NOT NULL,
    record_id INT NOT NULL,
    old_values JSON,
    new_values JSON,
    changed_by INT,
    changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ip_address VARCHAR(45),
    user_agent TEXT,
    FOREIGN KEY (changed_by) REFERENCES users(user_id),
    INDEX idx_audit_table (table_name),
    INDEX idx_audit_operation (operation),
    INDEX idx_audit_user (changed_by),
    INDEX idx_audit_date (changed_at)
) ENGINE=InnoDB;

-- ===================================================================
-- 10. VIEWS FOR REPORTING AND ANALYTICS
-- ===================================================================

-- Current Stock Levels View
CREATE VIEW v_current_stock AS
SELECT 
    p.product_id,
    p.sku,
    p.product_name,
    c.category_name,
    w.warehouse_name,
    s.quantity_on_hand,
    s.quantity_reserved,
    s.quantity_available,
    s.average_cost,
    (s.quantity_available * s.average_cost) as stock_value,
    p.min_stock_level,
    p.reorder_point,
    CASE 
        WHEN s.quantity_available <= p.min_stock_level THEN 'LOW_STOCK'
        WHEN s.quantity_available <= p.reorder_point THEN 'REORDER'
        ELSE 'SUFFICIENT'
    END as stock_status
FROM stock s
JOIN products p ON s.product_id = p.product_id
JOIN categories c ON p.category_id = c.category_id
JOIN warehouses w ON s.warehouse_id = w.warehouse_id
WHERE p.is_active = TRUE AND w.is_active = TRUE;

-- Sales Summary View
CREATE VIEW v_sales_summary AS
SELECT 
    c.customer_id,
    c.customer_name,
    COUNT(DISTINCT so.so_id) as total_orders,
    SUM(so.total_amount) as total_sales,
    AVG(so.total_amount) as average_order_value,
    MAX(so.so_date) as last_order_date
FROM customers c
LEFT JOIN sales_orders so ON c.customer_id = so.customer_id
WHERE c.is_active = TRUE
GROUP BY c.customer_id, c.customer_name;

-- Purchase Summary View
CREATE VIEW v_purchase_summary AS
SELECT 
    s.supplier_id,
    s.supplier_name,
    COUNT(DISTINCT po.po_id) as total_orders,
    SUM(po.total_amount) as total_purchases,
    AVG(po.total_amount) as average_order_value,
    MAX(po.po_date) as last_order_date
FROM suppliers s
LEFT JOIN purchase_orders po ON s.supplier_id = po.supplier_id
WHERE s.is_active = TRUE
GROUP BY s.supplier_id, s.supplier_name;


CREATE OR REPLACE VIEW v_purchase_summary AS
SELECT 
    s.supplier_id,
    s.supplier_name,
    COUNT(DISTINCT po.po_id) AS total_orders,
    SUM(po.total_amount) AS total_purchases,
    AVG(po.total_amount) AS average_order_value,
    MAX(po.po_date) AS last_order_date
FROM suppliers s
LEFT JOIN purchase_orders po ON s.supplier_id = po.supplier_id
WHERE s.is_active = TRUE
GROUP BY s.supplier_id, s.supplier_name;


-- Product Performance View
CREATE VIEW v_product_performance AS
SELECT 
    p.product_id,
    p.sku,
    p.product_name,
    c.category_name,
    COALESCE(sales_data.total_sold, 0) as total_quantity_sold,
    COALESCE(sales_data.total_revenue, 0) as total_revenue,
    COALESCE(purchase_data.total_purchased, 0) as total_quantity_purchased,
    COALESCE(purchase_data.total_cost, 0) as total_cost,
    COALESCE(current_stock.total_stock, 0) as current_stock_quantity,
    COALESCE(current_stock.stock_value, 0) as current_stock_value
FROM products p
LEFT JOIN categories c ON p.category_id = c.category_id
LEFT JOIN (
    SELECT 
        soi.product_id,
        SUM(soi.quantity_ordered) as total_sold,
        SUM(soi.line_total) as total_revenue
    FROM sales_order_items soi
    JOIN sales_orders so ON soi.so_id = so.so_id
    WHERE so.status NOT IN ('CANCELLED', 'DRAFT')
    GROUP BY soi.product_id
) sales_data ON p.product_id = sales_data.product_id
LEFT JOIN (
    SELECT 
        poi.product_id,
        SUM(poi.quantity_received) as total_purchased,
        SUM(poi.quantity_received * poi.unit_cost) as total_cost
    FROM purchase_order_items poi
    JOIN purchase_orders po ON poi.po_id = po.po_id
    WHERE po.status NOT IN ('CANCELLED', 'DRAFT')
    GROUP BY poi.product_id
) purchase_data ON p.product_id = purchase_data.product_id
LEFT JOIN (
    SELECT 
        product_id,
        SUM(quantity_available) as total_stock,
        SUM(quantity_available * average_cost) as stock_value
    FROM stock
    GROUP BY product_id
) current_stock ON p.product_id = current_stock.product_id
WHERE p.is_active = TRUE;

-- Low Stock Alert View
CREATE VIEW v_low_stock_alerts AS
SELECT 
    p.product_id,
    p.sku,
    p.product_name,
    c.category_name,
    w.warehouse_name,
    s.quantity_available,
    p.min_stock_level,
    p.reorder_point,
    CASE 
        WHEN s.quantity_available <= 0 THEN 'OUT_OF_STOCK'
        WHEN s.quantity_available <= p.min_stock_level THEN 'CRITICAL'
        WHEN s.quantity_available <= p.reorder_point THEN 'LOW'
    END as alert_level
FROM stock s
JOIN products p ON s.product_id = p.product_id
JOIN categories c ON p.category_id = c.category_id
JOIN warehouses w ON s.warehouse_id = w.warehouse_id
WHERE s.quantity_available <= p.reorder_point
    AND p.is_active = TRUE 
    AND w.is_active = TRUE
ORDER BY 
    CASE 
        WHEN s.quantity_available <= 0 THEN 1
        WHEN s.quantity_available <= p.min_stock_level THEN 2
        WHEN s.quantity_available <= p.reorder_point THEN 3
    END,
    s.quantity_available ASC;

-- Expiring Products View
CREATE VIEW v_expiring_products AS
SELECT 
    pb.batch_id,
    pb.batch_number,
    p.sku,
    p.product_name,
    w.warehouse_name,
    pb.expiry_date,
    pb.current_quantity,
    DATEDIFF(pb.expiry_date, CURDATE()) as days_to_expiry,
    CASE 
        WHEN pb.expiry_date < CURDATE() THEN 'EXPIRED'
        WHEN DATEDIFF(pb.expiry_date, CURDATE()) <= 7 THEN 'EXPIRES_SOON'
        WHEN DATEDIFF(pb.expiry_date, CURDATE()) <= 30 THEN 'EXPIRES_THIS_MONTH'
        ELSE 'GOOD'
    END as expiry_status
FROM product_batches pb
JOIN products p ON pb.product_id = p.product_id
JOIN warehouses w ON pb.warehouse_id = w.warehouse_id
WHERE pb.current_quantity > 0
    AND pb.expiry_date IS NOT NULL
    AND pb.is_active = TRUE
    AND p.is_active = TRUE
ORDER BY pb.expiry_date ASC;


-- For better performance on common queries creating INDEX

CREATE INDEX idx_stock_movements_date_type ON stock_movements(movement_date, movement_type);
CREATE INDEX idx_invoices_customer_status ON invoices(customer_id, status);
CREATE INDEX idx_products_category_active ON products(category_id, is_active);

-- View: Weighted Average Inventory Cost per Product
CREATE OR REPLACE VIEW v_weighted_avg_cost AS
SELECT
    p.product_id,
    p.product_name,
    SUM(poi.quantity_received) AS total_units_purchased,
    SUM(poi.quantity_received * poi.unit_cost) AS total_cost,
    ROUND(SUM(poi.quantity_received * poi.unit_cost) / NULLIF(SUM(poi.quantity_received), 0), 2) AS avg_unit_cost
FROM products p
JOIN purchase_order_items poi ON p.product_id = poi.product_id
JOIN purchase_orders po ON poi.po_id = po.po_id
WHERE po.status IN ('RECEIVED', 'PARTIALLY_RECEIVED', 'CONFIRMED')
GROUP BY p.product_id, p.product_name;

DELIMITER $$

CREATE TRIGGER trg_after_purchase_receipt_insert
AFTER INSERT ON purchase_receipt_items
FOR EACH ROW
BEGIN
    DECLARE existing_stock_id INT;

    -- Check if stock entry exists
    SELECT stock_id INTO existing_stock_id
    FROM stock
    WHERE product_id = NEW.product_id
      AND warehouse_id = (SELECT warehouse_id FROM purchase_receipts WHERE receipt_id = NEW.receipt_id)
      AND (batch_id = NEW.batch_id OR (batch_id IS NULL AND NEW.batch_id IS NULL))
    LIMIT 1;

    -- If exists, update quantity_on_hand and average_cost
    IF existing_stock_id IS NOT NULL THEN
        UPDATE stock
        SET 
            quantity_on_hand = quantity_on_hand + NEW.quantity_received,
            average_cost = ROUND((average_cost * quantity_on_hand + NEW.unit_cost * NEW.quantity_received) / (quantity_on_hand + NEW.quantity_received), 4),
            last_updated = NOW()
        WHERE stock_id = existing_stock_id;
    ELSE
        -- Else insert new stock record
        INSERT INTO stock (product_id, warehouse_id, batch_id, quantity_on_hand, quantity_reserved, average_cost)
        VALUES (
            NEW.product_id,
            (SELECT warehouse_id FROM purchase_receipts WHERE receipt_id = NEW.receipt_id),
            NEW.batch_id,
            NEW.quantity_received,
            0,
            NEW.unit_cost
        );
    END IF;
END$$

DELIMITER ;



DELIMITER $$

CREATE TRIGGER trg_after_invoice_insert
AFTER INSERT ON invoice_items
FOR EACH ROW
BEGIN
    DECLARE stock_id_val INT;

    -- Find matching stock record
    SELECT stock_id INTO stock_id_val
    FROM stock
    WHERE product_id = NEW.product_id
      AND warehouse_id = (SELECT warehouse_id FROM invoices i JOIN sales_orders so ON i.so_id = so.so_id WHERE i.invoice_id = NEW.invoice_id)
      AND (batch_id = NEW.batch_id OR (batch_id IS NULL AND NEW.batch_id IS NULL))
    LIMIT 1;

    -- Deduct from quantity_on_hand
    IF stock_id_val IS NOT NULL THEN
        UPDATE stock
        SET 
            quantity_on_hand = quantity_on_hand - NEW.quantity,
            last_updated = NOW()
        WHERE stock_id = stock_id_val;
    END IF;
END$$

DELIMITER ;



-- Add check constraints for business rules
ALTER TABLE products ADD CONSTRAINT chk_prices CHECK (unit_price >= 0 AND cost_price >= 0);
ALTER TABLE stock ADD CONSTRAINT chk_quantities CHECK (quantity_on_hand >= 0 AND quantity_reserved >= 0);