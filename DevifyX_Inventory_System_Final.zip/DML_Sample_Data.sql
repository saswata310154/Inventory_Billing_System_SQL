---ROLES table

INSERT INTO roles (role_name, description, permissions)
VALUES 
('admin', 'Full access', JSON_OBJECT('access', 'all')),
('manager', 'Can manage orders and stock', JSON_OBJECT('access', 'orders,stock'));

--- USERS table

INSERT INTO users (username, email, password_hash, role_id)
VALUES
('admin_user', 'admin@devifyx.com', 'hashed_admin_pass', 1),
('stock_manager', 'manager@devifyx.com', 'hashed_manager_pass', 2);

---WAEHOUSE table

INSERT INTO warehouses (warehouse_code, warehouse_name, city, state, country, is_active)
VALUES
('WH01', 'Central Warehouse', 'Kolkata', 'WB', 'India', TRUE),
('WH02', 'Secondary Warehouse', 'Delhi', 'DL', 'India', TRUE);

---CATEGORIS table

INSERT INTO categories (category_name, description)
VALUES
('Electronics', 'Electronic items like TVs, laptops'),
('Stationery', 'Office and school supplies');


---PRODUCTS table

INSERT INTO products (sku, product_name, category_id, unit_price, cost_price, has_batches, is_active)
VALUES
('ELEC001', 'LED Monitor 24"', 1, 12000, 9500, TRUE, TRUE),
('STAT001', 'A4 Notebook', 2, 50, 30, FALSE, TRUE);

---PRODUCT_BATCHES table

INSERT INTO product_batches (product_id, batch_number, manufacture_date, expiry_date, initial_quantity, current_quantity, cost_per_unit, warehouse_id)
VALUES
(1, 'BATCH01', '2024-01-10', '2026-01-10', 100, 100, 9500, 1);


SUPPLIERS table

INSERT INTO suppliers (supplier_code, supplier_name, city, state, country)
VALUES
('SUP001', 'TechSupply Ltd.', 'Mumbai', 'MH', 'India');


---CUSTOMERS table

INSERT INTO customers (customer_code, customer_name, customer_type, city, state, country)
VALUES
('CUST001', 'John Traders', 'RETAIL', 'Chennai', 'TN', 'India'),
('CUST002', 'Books & Co.', 'WHOLESALE', 'Kolkata', 'WB', 'India');


---PURCHASE_ORDERS table
INSERT INTO purchase_orders (po_number, supplier_id, warehouse_id, po_date, status, created_by)
VALUES
('PO202401', 1, 1, '2025-06-20', 'CONFIRMED', 1);

---PURCHASE_ORDER_ITEMS table

INSERT INTO purchase_order_items (po_id, product_id, quantity_ordered, unit_cost)
VALUES
(1, 1, 100, 9500);


--- PURCHASE_RECEIPTS table

INSERT INTO purchase_receipts (receipt_number, po_id, supplier_id, warehouse_id, receipt_date, created_by)
VALUES
('RCPT202401', 1, 1, 1, '2025-06-21', 1);

--- PURCHASE_RECEIPTS_ITEMS table

INSERT INTO purchase_receipt_items (receipt_id, product_id, batch_id, quantity_received, unit_cost)
VALUES
(1, 1, 1, 100, 9500);

---SALES_ORDERS table

INSERT INTO sales_orders (so_number, customer_id, warehouse_id, so_date, status, created_by)
VALUES
('SO202401', 1, 1, '2025-06-21', 'CONFIRMED', 2);


---SALES_ORDER_ITEMS table

INSERT INTO sales_order_items (so_id, product_id, quantity_ordered, unit_price)
VALUES
(1, 1, 10, 12000);


--- INVOICES table

INSERT INTO invoices (invoice_number, so_id, customer_id, invoice_date, due_date, status, total_amount, created_by)
VALUES
('INV202401', 1, 1, '2025-06-22', '2025-07-22', 'SENT', 120000, 2);

--- INVOICES_ITEMS table

INSERT INTO invoice_items (invoice_id, product_id, batch_id, quantity, unit_price)
VALUES
(1, 1, 1, 10, 12000);

---PAYMENT table

INSERT INTO payments (payment_number, invoice_id, customer_id, payment_date, payment_method, amount, created_by)
VALUES
('PMT202401', 1, 1, '2025-06-22', 'CASH', 120000, 2);


---STOCK_MOVEMENTS table

INSERT INTO stock_movements (product_id, warehouse_id, batch_id, movement_type, reference_type, reference_id, quantity, unit_cost, total_cost, created_by)
VALUES
(1, 1, 1, 'IN', 'PURCHASE', 1, 100, 9500, 950000, 1),
(1, 1, 1, 'OUT', 'SALE', 1, 10, 9500, 95000, 2);


---AUDIT_LOGS table

INSERT INTO audit_logs (table_name, operation, record_id, new_values, changed_by)
VALUES
('products', 'INSERT', 1, JSON_OBJECT('product_name', 'LED Monitor 24"'), 1);













